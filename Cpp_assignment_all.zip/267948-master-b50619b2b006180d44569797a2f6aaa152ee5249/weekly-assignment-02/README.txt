1. class is a data structure with , where the difference with structure is it can contain menthods and private, public, protected properties. But object is a variable of the specific class type.
2. the public interface of a class is the properties , usually methods, that can be accessed with object creation from outside of class.
3. the private interface of a class is the properties, usually variables, that can only be accessed by the methods of a class while creating an object from inside the class.
