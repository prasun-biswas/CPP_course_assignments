#ifndef READ_AND_STORE_H
#define READ_AND_STORE_H

#include<iostream>
#include<string>
#include<map>
#include<vector>

using namespace std;

map <string, map<string, map<string, double>>> read_and_store_map(const string & filename);

//class Read_and_store
//{
//public:
//    Read_and_store();
//};


#endif // READ_AND_STORE_H
