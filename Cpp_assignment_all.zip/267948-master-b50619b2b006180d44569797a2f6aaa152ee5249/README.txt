This file and a file named .gitignore has been automatically
created during the initialization of your git-repository.

- What ever you do, don't delete .gitignore-file.  Its purpose
  is to make sure no unneccessary files will end up in your
  version control repository.

- Subdirectory/subfolder .git is an integral part on Git-system.
  Please don't touch it or its content unless you know what
  you are doing.

- There is an experimental directory named common in your
  project's root directory.  You can/should ignore it
  unless otherwise adviced.  It may or may not be used to
  share course material later on.  We will see.. unless we won't.

- This README.txt serves no particular purpose and you
  can delete it if it bothers you.

//aps
