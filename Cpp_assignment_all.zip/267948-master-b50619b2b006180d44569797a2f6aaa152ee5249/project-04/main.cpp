#include "function_chores.h"

int main(){

    function_Chores chores;
    chores.prompt();
    return 0;
}
